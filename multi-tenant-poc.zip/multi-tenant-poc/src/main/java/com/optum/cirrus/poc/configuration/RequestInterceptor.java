package com.optum.cirrus.poc.configuration;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
public class RequestInterceptor implements HandlerInterceptor {
    private static final String TENANT_HEADER = "X-TENANT-ID";

    @Override
    public boolean preHandle(HttpServletRequest request,HttpServletResponse response,
                             Object object) throws Exception {

        System.out.println("### Inside PRE HANDLE in Interceptor......");
        String requestURI = request.getRequestURI();
        String tenantID = request.getHeader(TENANT_HEADER);
        log.info("Request Interceptor requested URI: {}, X-TENANT-ID: {}", requestURI, tenantID);

        if (StringUtils.isBlank(tenantID)) {
            response.getWriter().write("X-TENANT-ID not present in the request header");
            response.setStatus(400);
            return false;
        }
        TenantContext.setCurrentTenant(tenantID);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response,
                           Object handler, ModelAndView modelAndView) {

        System.out.println("### Inside POST HANDLE in Interceptor......");
        TenantContext.clear();
    }

}
