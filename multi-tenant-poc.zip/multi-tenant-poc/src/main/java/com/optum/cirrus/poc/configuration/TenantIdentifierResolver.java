package com.optum.cirrus.poc.configuration;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;

public class TenantIdentifierResolver implements CurrentTenantIdentifierResolver {
    private static String DEFAULT_TENANT_ID = "fedex";

    @Override
    public String resolveCurrentTenantIdentifier() {
        String currentTenantId = TenantContext.getCurrentTenant();
        currentTenantId = StringUtils.isNotBlank(currentTenantId) ? currentTenantId : DEFAULT_TENANT_ID;
        return currentTenantId;
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return false;
    }
}
