package com.optum.cirrus.poc.service;

import com.optum.cirrus.poc.model.Member;
import com.optum.cirrus.poc.repository.MemberRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * MemberService class used to create and search members information for given criteria.
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Service
@Slf4j
public class MemberService {

    @Autowired
    private MemberRepo memberRepo;


    /**
     * Method to create or save member and ingest data into DB.
     *
     * @param member
     * @return Member
     */
    public Member create(Member member) {
        Member savedMember = memberRepo.save(member);
        return savedMember;
    }


    /**
     * Method to search by member by member id.
     *
     * @param memberId
     * @return Member
     */
    public Member getMemberById(String memberId) {
        Member searchedMember = memberRepo.findByMemberId(memberId);
        return searchedMember;
    }

    /**
     * Method to search members by group id.
     *
     * @param groupId
     * @return List
     */
    public List<Member> getMembersByGroupId(String groupId) {
        log.info("Searching members by group id: {}", groupId);
        List<Member> searchedMember = memberRepo.findByGroupId(groupId);
        return searchedMember;
    }

    /**
     * Method to search member by policy number.
     *
     * @param policyNr
     * @return List
     */
    public List<Member> getMembersByPolicyNr(String policyNr) {
        log.info("Searching members by policy number: {}", policyNr);
        List<Member> searchedMember = memberRepo.findByPolicyNr(policyNr);
        return searchedMember;
    }

}
