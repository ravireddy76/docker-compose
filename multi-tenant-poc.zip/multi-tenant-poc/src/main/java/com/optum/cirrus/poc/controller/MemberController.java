package com.optum.cirrus.poc.controller;

import com.optum.cirrus.poc.model.Member;
import com.optum.cirrus.poc.service.MemberService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
@RequestMapping(value = "/multitenant", produces = MediaType.APPLICATION_JSON_VALUE)
@Api(value = "/multitenantt", description = "multi tenant db poc")
@Slf4j
public class MemberController {

    @Autowired
    public MemberService memberService;


    /**
     * Method to create member.
     *
     * @param member
     * @return ResponseEntity
     */
    @SuppressWarnings("unchecked")
    @ApiOperation(value = "", notes = "Create new member")
    @RequestMapping(value = "/member", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Member> create(@RequestBody Member member) {
        try {
            log.info("Creating new member: {}", member.toString());
            Member createdMember = memberService.create(member);
            return new ResponseEntity<>(createdMember, HttpStatus.OK);
        } catch (Exception ex) {
            log.error("Issues to create or register member: {}", ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Method to get member by memberId.
     *
     * @param memberId
     * @return ResponseEntity
     */
    @SuppressWarnings("unchecked")
    @ApiOperation(value = "", notes = "Get member by member id")
    @RequestMapping(value = "/member/id/{memberId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Member> getMemberById(@PathVariable String memberId) {
        try {
            log.info("Search member by memberId : " + memberId);
            Member searchedMember = memberService.getMemberById(memberId);
            return new ResponseEntity<>(searchedMember, HttpStatus.OK);
        } catch (Exception ex) {
            log.error("Issues to get member by memberId: {}, with exception: {}", memberId, ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Method to get members by group id.
     *
     * @param groupId
     * @return ResponseEntity
     */
    @SuppressWarnings("unchecked")
    @ApiOperation(value = "", notes = "Get members by group id")
    @RequestMapping(value = "/members/group/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Member>> getMembersByGroupId(@PathVariable String groupId) {
        try {
            log.info("Search members by groupId : " + groupId);
            List<Member> searchedMembers = memberService.getMembersByGroupId(groupId);
            return new ResponseEntity<>(searchedMembers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error("Issues to get members by groupId: {}, with exception: {}", groupId, ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }


    /**
     * Method to get members by policy number.
     *
     * @param policyNr
     * @return ResponseEntity
     */
    @SuppressWarnings("unchecked")
    @ApiOperation(value = "", notes = "Get members by policy number")
    @RequestMapping(value = "/members/policy/{policyNr}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Member>> getMembersByPolicyNr(@PathVariable String policyNr) {
        try {
            log.info("Search members by policy number: " + policyNr);
            List<Member> searchedMembers = memberService.getMembersByPolicyNr(policyNr);
            return new ResponseEntity<>(searchedMembers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error("Issues to get members by policy number: {}, with exception: {}", policyNr, ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

}
