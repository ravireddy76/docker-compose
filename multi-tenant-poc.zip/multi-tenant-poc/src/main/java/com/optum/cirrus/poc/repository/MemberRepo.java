package com.optum.cirrus.poc.repository;

import com.optum.cirrus.poc.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * MemberRepo class used to query member data by query criteria.
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Repository
@Transactional
public interface MemberRepo extends JpaRepository<Member, String> {

    /**
     * Method to find member by member id.
     *
     * @param memberId
     * @return List
     */
    Member findByMemberId(String memberId);


    /**
     * Method to find member by group id.
     *
     * @param groupId
     * @return List
     */
    List<Member> findByGroupId(String groupId);

    /**
     * Method to find member by policy number.
     *
     * @param policyN
     * @return List
     */
    List<Member> findByPolicyNr(String policyN);

}
