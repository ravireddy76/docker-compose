package com.optum.cirrus.poc.configuration;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@ConfigurationProperties("multitenancy.member")
public class MultiTenantProperties {

    @Getter
    @Setter
    private List<DataSourceProperties> dataSources;

    public static class DataSourceProperties extends org.springframework.boot.autoconfigure.jdbc.DataSourceProperties {
        @Getter
        @Setter
        private String tenantId;
    }

}
