package com.optum.cirrus.poc.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.Date;


/**
 * MemberClaims entity is used to map the data of
 * <p>
 * <i> <b>Table = member </b> under <br/>
 * <b>Schema = mbrdata </b> with in the enterprise application. </i>
 * </p>
 *
 * @author Ravi
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Entity
@Table(name = "member", schema = "mbrdata")
@Data
@NoArgsConstructor
public class Member {

    @Id
    @Column(name = "memberid", nullable = false, length = 50)
    private String memberId;

    @Column(name = "firstname", nullable = false, length = 50)
    private String firstName;

    @Column(name = "lastname", nullable = false, length = 50)
    private String lastName;

    @Column(name = "birthdate", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "UTC")
    private Date birthDate;

    @Column(name = "groupid", nullable = false, length = 50)
    private String groupId;

    @Column(name = "policynr", nullable = false, length = 50)
    private String policyNr;

    @Column(name = "address", nullable = false, length = 50)
    private String address;

}
