package com.optum.cirrus.poc.configuration;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;
import java.util.Map;

public class MultiTenantConnectionProviderImpl extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {
    @Autowired
    private Map<String, DataSource> dataSourcesMultiTenant;


    @Override
    protected DataSource selectAnyDataSource() {
        return this.dataSourcesMultiTenant.values().iterator().next();
    }

    @Override
    protected DataSource selectDataSource(String tenantIdentifier) {
        return this.dataSourcesMultiTenant.get(tenantIdentifier);
    }

}
