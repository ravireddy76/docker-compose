#!/bin/bash
txFile='transId-50k.txt'
jwtToken='eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSTEVJIiwiZXhwIjoxNjIwMjUxMzkwfQ.IcSzNZe_Do6h9y9N2p-5v0oDTfAdZJjOgVBuen7Mtg11Je-e4h1WcFjA04fYH_fZZ61M7Lg7VjRWkrNskioKYQ'
SECONDS=0

while read txId;
do
  echo "Consuming tx archive service for transaction id: $txId"
  curl -X POST "https://transaction-cirrusperf.ocp-elr-core-stg.optum.com/cirrus/v2.0/archive/transaction/$txId" -H "accept: */*" -H "X-Authn-JWT: $jwtToken"
  echo
  echo
done < $txFile

echo
ELAPSED="Elapsed: $(($SECONDS / 3600))hrs $((($SECONDS / 60) % 60))min $(($SECONDS % 60))sec"
echo "$ELAPSED"
