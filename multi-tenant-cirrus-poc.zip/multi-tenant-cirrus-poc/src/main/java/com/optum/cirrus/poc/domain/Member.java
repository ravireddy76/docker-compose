package com.optum.cirrus.poc.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.optum.ocf.dao.data.ValueObject;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

/**
 * Member entity is used to map the data of
 * <p>
 * <i> <b>Table = member </b> under <br/>
 * <b>Schema = mbrdata </b> with in the enterprise application. </i>
 * </p>
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
public class Member extends ValueObject {

    private String memberId;
    private String firstName;
    private String lastName;
    private Date birthDate;
    private String groupId;
    private String policyNr;
    private String address;
}
