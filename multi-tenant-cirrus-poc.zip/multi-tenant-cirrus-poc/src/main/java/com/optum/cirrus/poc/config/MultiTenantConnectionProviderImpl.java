/*
package com.optum.cirrus.poc.config;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;
import java.util.Map;

*/
/**
 * MultiTenantConnectionProviderImpl class used to configure and analyze data source based on tenant id.
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 *//*

public class MultiTenantConnectionProviderImpl extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {
    @Autowired
    private Map<String, DataSource> dataSourcesMultiTenant;


    @Override
    protected DataSource selectAnyDataSource() {
        return this.dataSourcesMultiTenant.values().iterator().next();
    }

    @Override
    protected DataSource selectDataSource(String tenantIdentifier) {
        return this.dataSourcesMultiTenant.get(tenantIdentifier);
    }

}
*/
