package com.optum.cirrus.poc.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * MultiTenantProperties class used to read or map properties tenant data source configuration from *.yml file.
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
@Configuration
@ConfigurationProperties("multitenancy.rso")
public class MultiTenantProperties {

    private List<DataBaseProperties> dataSources;
}
