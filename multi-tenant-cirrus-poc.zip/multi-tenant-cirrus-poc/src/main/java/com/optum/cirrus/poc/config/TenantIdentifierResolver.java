//package com.optum.cirrus.poc.config;
//
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
//
///**
// * TenantIdentifierResolver class used to identify, resolver and set current tenant id to .
// *
// * @author Ravi Reddy
// * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
// */
//@Slf4j
//public class TenantIdentifierResolver implements CurrentTenantIdentifierResolver {
//    private static String DEFAULT_TENANT_ID = "fedex";
//
//    @Override
//    public String resolveCurrentTenantIdentifier() {
//        String currentTenantId = TenantContext.getCurrentTenant();
//        currentTenantId = StringUtils.isNotBlank(currentTenantId) ? currentTenantId : DEFAULT_TENANT_ID;
//
//        log.info("Current Tenant: {}", currentTenantId);
//        return currentTenantId;
//    }
//
//    @Override
//    public boolean validateExistingCurrentSessions() {
//        return false;
//    }
//}
