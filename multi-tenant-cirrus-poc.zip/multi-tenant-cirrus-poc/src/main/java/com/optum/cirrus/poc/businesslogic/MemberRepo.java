package com.optum.cirrus.poc.businesslogic;

import com.optum.cirrus.poc.domain.MemberVO;
import com.optum.ocf.bl.businesslogic.v2.AbstractComponentChildLogic;
import com.optum.ocf.bl.businesslogic.v2.BusinessLogicConfiguration;
import com.optum.ocf.bl.constants.ComponentType;
import com.optum.ocf.dao.data.ValueObject;
import com.optum.ocf.dao.sql.DataAccessObject;
import com.optum.ocf.dao.sql.exception.FinderException;

public class MemberRepo extends AbstractComponentChildLogic<MemberVO> {
    private static final BusinessLogicConfiguration DEFAULT_BUSINESS_LOGIC_CONFIGURATION = BusinessLogicConfiguration.builder().build();

    private DataAccessObject<MemberVO> dao;

    protected MemberRepo(String tableName, ComponentType type) {
        super(tableName, type);
    }

    public final void setRequiredDao(DataAccessObject<MemberVO> dao) {
        this.dao = dao;
    }


    @Override
    protected DataAccessObject getDao() {
        return this.dao;
    }

    @Override
    protected boolean isParentAssigned(MemberVO vo) throws FinderException {
        return false;
    }


    public


}
