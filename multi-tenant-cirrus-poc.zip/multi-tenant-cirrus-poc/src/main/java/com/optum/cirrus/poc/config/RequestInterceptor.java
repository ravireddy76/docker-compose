package com.optum.cirrus.poc.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * RequestInterceptor class used to intercept all incoming request and compute for tenant id header.
 *
 * @author Ravi Reddy
 * @CopyRight (C) All rights reserved to E&A team. It's Illegal to reproduce this code.
 */
@Component
@Slf4j
public class RequestInterceptor implements HandlerInterceptor {
	private static final String TENANT_HEADER = "X-TENANT-ID";

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object object, Exception arg3)
			throws Exception {
	}

	@Override
	public void postHandle(HttpServletRequest request,
						   HttpServletResponse response, Object object, ModelAndView model) throws Exception {

		TenantContext.clear();
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object object) throws Exception {

		String requestURI = request.getRequestURI();
		String tenantID = request.getHeader(TENANT_HEADER);
		log.info("Request Interceptor requested URI: {}, X-TENANT-ID: {}", requestURI, tenantID);

//		if (StringUtils.isBlank(tenantID)) {
//			response.getWriter().write("X-TENANT-ID not present in the request header");
//			response.setStatus(400);
//			return false;
//		}

		TenantContext.setCurrentTenant(tenantID);
		return true;
	}

}