package com.optum.cirrus.poc.config;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DataBaseProperties {
    private String tenantId;
    private String url;
    private String username;
    private String password;
    private int minPoolSize;
    private int maxPoolSize;
    private int minEvictableIdleTimeMillis;
    private int timeBetweenEvictionRunsMillis;
    private String driverClassName;
    
}
