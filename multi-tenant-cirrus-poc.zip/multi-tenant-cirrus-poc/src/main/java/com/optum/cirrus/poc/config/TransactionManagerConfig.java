package com.optum.cirrus.poc.config;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Aspect
@Configuration
@ImportResource({"classpath*:transactionContext.xml"})
public class TransactionManagerConfig {

    @Pointcut("@execution(* com.optum..businesslogic..*.*(..))")
    public void businessLogicTxPC() {}

    @Pointcut("@within(@com.optum.cirrus.pricing.annotation.PricingBusinessLogic *)")
    public void businessLogicTxPC_Pric01() {}

}
