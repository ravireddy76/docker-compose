package com.optum.cirrus.poc.domain;

public class MemberVO extends Member {

}
