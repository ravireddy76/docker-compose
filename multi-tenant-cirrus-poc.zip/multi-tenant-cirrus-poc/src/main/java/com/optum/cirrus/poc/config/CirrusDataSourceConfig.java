package com.optum.cirrus.poc.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.jdbc.pool.DataSourceFactory;
import org.apache.tomcat.jdbc.pool.PoolConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jmx.export.MBeanExporter;

import javax.management.ObjectName;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Driver;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@Configuration
@Slf4j
public class CirrusDataSourceConfig {

    @Autowired
    private MBeanExporter mBeanExporter;

    @Autowired
    private MultiTenantProperties multiTenantProperties;


    @Bean
    public Map<String, DataSource> dataSourcesMultiTenant() throws Exception {
        Map<String, DataSource> mtDataSources = new HashMap<>();

        /** Build the configured data source. */
        for (DataBaseProperties dbProperties : this.multiTenantProperties.getDataSources()) {
            DataSource dataSource = buildDataSource(dbProperties);
            mtDataSources.put(dbProperties.getTenantId(), dataSource);
        }

        return mtDataSources;
    }

    /**
     * Method to build the data source for given database properties.
     *
     * @param dataBaseProperties
     * @return DataSource
     * @throws Exception
     */
    private DataSource buildDataSource(DataBaseProperties dataBaseProperties) throws Exception {
        Properties props = new Properties();
        PoolConfiguration poolProperties = DataSourceFactory.parsePoolProperties(props);

        /* Build ppol configuration for data source. */
        poolProperties.setIgnoreExceptionOnPreLoad(true);
        poolProperties.setDefaultAutoCommit(true);
        poolProperties.setDriverClassName(Driver.class.getName());
        poolProperties.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
        poolProperties.setMaxIdle(dataBaseProperties.getMaxPoolSize());
        poolProperties.setInitialSize(dataBaseProperties.getMinPoolSize());
        poolProperties.setMaxActive(dataBaseProperties.getMaxPoolSize());

        poolProperties.setUsername(dataBaseProperties.getUsername());
        poolProperties.setPassword(dataBaseProperties.getPassword());
        poolProperties.setUrl(dataBaseProperties.getUrl());
        log.info("***** Configured DataSource URL *****: {}", dataBaseProperties.getUrl());

        poolProperties.setTestOnBorrow(true);
        poolProperties.setTestWhileIdle(true);
        poolProperties.setValidationQuery("select 1");
        poolProperties.setValidationInterval(5000);
        poolProperties.setMinEvictableIdleTimeMillis(dataBaseProperties.getMinEvictableIdleTimeMillis());
        poolProperties.setTimeBetweenEvictionRunsMillis(dataBaseProperties.getTimeBetweenEvictionRunsMillis());

        org.apache.tomcat.jdbc.pool.DataSource dataSource = new org.apache.tomcat.jdbc.pool.DataSource(poolProperties);

        /* Initialize the pool itself. */
        dataSource.createPool();

        /* Register Connection Pool with MBeanServer. */
        if (mBeanExporter != null) {

            //TODO Need to ask Question to Jesse where is object name below configured code.
            mBeanExporter.registerManagedResource(dataSource, new ObjectName("com.optum.cirrus.datasource.connectionpool:type=PooledDataSource,name=internalDatasourcePric01,database=${mysqlPricingConfiguration.database}"));
        }

        return dataSource;
    }

}
