export class Member {
    public memberGroup: string;
    public benefitType: string;
    public membershipDate: string;
    public singleSubscribers: string;
    public subscribersSpouse: string;
    public subscribersChild: string;
    public subscribersFamily: string;
    public totalSubscribers: string;
    public totalMembers: string;

    constructor() { }
  
  }