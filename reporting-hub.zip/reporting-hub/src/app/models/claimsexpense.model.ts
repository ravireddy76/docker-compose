export class ClaimExpense {
    public range: string;
    public numberOfClaimants: string;
    public percentageClaimants: string;
    public totalPayments: string;
    public percentagePayments: string;
    
    constructor() { }
  
  }