export class ClaimExpenseSearch {
    public memberGroupId: String;
    public bookYear: string;
   
    constructor() { }
  
  }