export class MemberSearch {
    public memberGroupId: string;
    public govtBenefitType: string;
   
    constructor() { }
  
  }