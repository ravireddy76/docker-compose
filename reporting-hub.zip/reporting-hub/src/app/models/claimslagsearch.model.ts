export class ClaimLagSearch {
    public memberGroupId: String;
    public bookYear: string;
   
    constructor() { }
  
  }