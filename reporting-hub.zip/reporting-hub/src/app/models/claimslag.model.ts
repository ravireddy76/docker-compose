export class ClaimsLag {
    public serviceDate: string;
    public totalPaidAmount: string;
    
    constructor() { }
  
  }