package com.uhc.optum.party.configuration;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PartyDataConfig {

  @Value("${elastic.ES_HOST:elasticsearch}")
  private String elasticsearchHost;

  @Value("${elastic.ES_PORT:9200}")
  private int elasticsearchPort;

  @Value("${elastic.ES_HTTP_SCHEME:http}")
  private String elasticSearchHttpScheme;

  @Bean
  public RestHighLevelClient createESRestCleint() {
    RestHighLevelClient client =
        new RestHighLevelClient(RestClient.builder(new HttpHost(elasticsearchHost, elasticsearchPort, elasticSearchHttpScheme)));
    return client;
  }

  @Bean
  public ObjectMapper objectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    objectMapper.registerModule(new JodaModule());
    return objectMapper;
  }

  public String getElasticsearchHost() {
    return elasticsearchHost;
  }

  public void setElasticsearchHost(String elasticsearchHost) {
    this.elasticsearchHost = elasticsearchHost;
  }

  public int getElasticsearchPort() {
    return elasticsearchPort;
  }

  public void setElasticsearchPort(int elasticsearchPort) {
    this.elasticsearchPort = elasticsearchPort;
  }

  public String getElasticSearchHttpScheme() {
    return elasticSearchHttpScheme;
  }

  public void setElasticSearchHttpScheme(String elasticSearchHttpScheme) {
    this.elasticSearchHttpScheme = elasticSearchHttpScheme;
  }
}
