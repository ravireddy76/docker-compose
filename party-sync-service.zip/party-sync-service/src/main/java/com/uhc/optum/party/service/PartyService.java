package com.uhc.optum.party.service;

import com.uhc.optum.party.dao.PartyElasticSearchDao;
import com.uhc.optum.party.model.PartyData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PartyService {

    @Autowired
    private PartyElasticSearchDao partyElasticSearchDao;

    public void testElasticConnection() {
        PartyData data = new PartyData();
        data.setPartyId("112233");
        data.setWritingId("ABC123");
        partyElasticSearchDao.saveParty(data);
    }
}
