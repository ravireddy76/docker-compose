package com.uhc.optum.party.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhc.optum.party.model.PartyData;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class PartyElasticSearchDao {

  public static final String PARTIES = "parties_test_sravi";
  @Autowired RestHighLevelClient restHighLevelClient;

  @Autowired ObjectMapper objectMapper;

  public PartyData saveParty(PartyData party) {
    //    objectMapper.registerModule(new JavaTimeModule());
    IndexRequest indexRequest = new IndexRequest(PARTIES);
    try {
      indexRequest.source(objectMapper.writeValueAsString(party), XContentType.JSON);
      RequestOptions reqOptions = RequestOptions.DEFAULT;
      IndexResponse indexResponse = restHighLevelClient.index(indexRequest, reqOptions);
      if (indexResponse.status().equals(RestStatus.CREATED)) {
        return party;
      }

    } catch (IOException e) {
      e.printStackTrace();
    }

    return null;
  }

}
