package com.uhc.optum.party.model;

import lombok.Data;

/**
 * Party Data sync
 */
@Data
public class PartyData {

    private String partyId;
    private String writingId;
}
