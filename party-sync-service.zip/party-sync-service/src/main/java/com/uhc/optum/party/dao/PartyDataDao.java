package com.uhc.optum.party.dao;

public class PartyDataDao {
}
