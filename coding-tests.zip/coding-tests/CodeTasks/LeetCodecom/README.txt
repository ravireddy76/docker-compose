   Code Tasks From LeetCode.com Site

   This module represents the implementation of some code assignments from the site. Here are the tasks related to the
 different branches of knowledge of the language of Java.

 Here are presented such tasks as:

     - Judge Route Circle;
     - Self Dividing Number;
     - Keyboard Row;
     - Toeplitz Matrix;
     - Single Number;
     - Find the Difference;
     - Roman to Integer;
     - First Unique Character in a String;
     - Valid Anagram;
     - Find Smallest Letter Greater Than Target;
     - Missing Number;
     - Largest Number At Least Twice of Others;
     - Merge Two Sorted Lists;
     - Two Sum;
     - Valid Parentheses;
     - Repeated String Match;
     - Sum of Square Numbers;
     - Min Stack;
     - Count Primes;
     - Reverse Integer;
     - Maximum Length of Pair Chain;
     - Decode String;
     - Maximum Length of Repeated SubArray;
     - Maximum Swap;
     - Add Two Numbers;
     - Longest Palindromic Substring;

