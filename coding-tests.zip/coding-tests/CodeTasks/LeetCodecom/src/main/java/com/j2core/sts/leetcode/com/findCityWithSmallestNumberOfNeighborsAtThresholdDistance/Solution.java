package com.j2core.sts.leetcode.com.findCityWithSmallestNumberOfNeighborsAtThresholdDistance;

public class Solution {

    public int findTheCity(int n, int[][] edges, int distanceThreshold) {


        return 0;
    }
}
