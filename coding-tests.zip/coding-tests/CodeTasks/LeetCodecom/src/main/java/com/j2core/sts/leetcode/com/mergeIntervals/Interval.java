package com.j2core.sts.leetcode.com.mergeIntervals;

public class Interval {

     int start;
     int end;

     Interval() {
         this.start = 0;
         this.end = 0;
     }

     Interval(int s, int e) {
         this.start = s;
         this.end = e;
     }
}
