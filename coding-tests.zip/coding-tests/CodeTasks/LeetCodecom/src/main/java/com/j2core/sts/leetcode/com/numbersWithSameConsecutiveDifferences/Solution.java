package com.j2core.sts.leetcode.com.numbersWithSameConsecutiveDifferences;

public class Solution {
}
