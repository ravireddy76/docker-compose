package com.j2core.sts.leetcode.com.sortList.README;

public class ListNode {

    int val;
    ListNode next;
    ListNode(int x) { val = x; }

}
