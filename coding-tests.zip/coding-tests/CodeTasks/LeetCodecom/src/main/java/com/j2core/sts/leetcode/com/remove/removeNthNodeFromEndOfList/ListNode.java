package com.j2core.sts.leetcode.com.remove.removeNthNodeFromEndOfList;

public class ListNode {

    int val;
    ListNode next;
    ListNode(int x) { val = x; }

}
