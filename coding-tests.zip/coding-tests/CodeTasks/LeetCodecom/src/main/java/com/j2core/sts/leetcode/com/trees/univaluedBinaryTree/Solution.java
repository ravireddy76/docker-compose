package com.j2core.sts.leetcode.com.trees.univaluedBinaryTree;

public class Solution {
}
