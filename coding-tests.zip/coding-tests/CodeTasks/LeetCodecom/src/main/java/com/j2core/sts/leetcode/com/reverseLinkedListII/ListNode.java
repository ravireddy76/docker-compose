package com.j2core.sts.leetcode.com.reverseLinkedListII;

public class ListNode {

    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
    }
}
