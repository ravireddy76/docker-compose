package com.j2core.sts.leetcode.com.max.maxPointsOnLine;

public class Solution {

    public int maxPoints(int[][] points) {

        //todo

        return 0;
    }
}
