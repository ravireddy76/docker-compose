package com.j2core.sts.leetcode.com.intervalListIntersections;

public class Interval {

    int start;
    int end;

    public Interval(int start, int end) {
        this.start = start;
        this.end = end;
    }

    public Interval(){
        this.start = 0;
        this.end = 0;
    }
}
