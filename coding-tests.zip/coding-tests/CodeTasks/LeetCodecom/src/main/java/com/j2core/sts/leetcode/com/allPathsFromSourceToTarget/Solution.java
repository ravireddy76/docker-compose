package com.j2core.sts.leetcode.com.allPathsFromSourceToTarget;

public class Solution {
}
