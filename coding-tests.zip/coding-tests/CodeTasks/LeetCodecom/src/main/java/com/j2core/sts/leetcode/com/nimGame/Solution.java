package com.j2core.sts.leetcode.com.nimGame;

public class Solution {

    public boolean canWinNim(int n) {

        return n%4 != 0;
    }
}
