package com.j2core.sts.leetcode.com.employeeFreeTime;

public class Interval {

    public int start;
    public int end;

    public Interval() {}

    public Interval(int _start, int _end) {
        start = _start;
        end = _end;
    }
}
